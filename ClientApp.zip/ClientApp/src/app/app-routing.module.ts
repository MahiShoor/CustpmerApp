import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from './Customer/customer-list/customer-list.component';
import { CustomerEditComponent } from './Customer/customer-edit/customer-edit.component';
import { CustomerAddComponent } from './Customer/customer-add/customer-add.component';

const routes: Routes = [
  {path:'' , component:CustomerListComponent},
  {path:'customer/edit/:id',component:CustomerEditComponent},
  {path:'customer/add',component:CustomerAddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
