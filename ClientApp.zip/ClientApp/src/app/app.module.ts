import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerListComponent } from './Customer/customer-list/customer-list.component';
import {HttpClientModule} from '@angular/common/http';
import { CustomerEditComponent } from './Customer/customer-edit/customer-edit.component';
import { FormsModule } from '@angular/forms';
import { CustomerAddComponent } from './Customer/customer-add/customer-add.component';
@NgModule({
  declarations: [
    AppComponent,
    CustomerListComponent,
    CustomerEditComponent,
    CustomerAddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
