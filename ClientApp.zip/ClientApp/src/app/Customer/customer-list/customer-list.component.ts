import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../../_services/customer-service.service';
import { Customer } from '../../_Models/customer.model';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {

  customerList:Customer[]=[];
  constructor(private customerService:CustomerServiceService) {
customerService.getCustomerList().subscribe(res=>{
  console.log(res);
  this.customerList= res;
 });
   }

  ngOnInit(): void {
  }
  deleteCustomer(customerId?:string){
    if(customerId){
      this.customerService.deleteCustomer(customerId!).subscribe(res=>{
        
        
      });
    }
  
  }
}
