import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Customer } from '../../_Models/customer.model';
import { CustomerServiceService } from '../../_services/customer-service.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css']
})
export class CustomerEditComponent implements OnInit {
customer:Customer={};

  constructor(private customerService:CustomerServiceService,private activeRout:ActivatedRoute) { 

  }

  ngOnInit(): void {
    let id= this.activeRout.paramMap.subscribe( paramMap=>{
      this.getCustomerById(paramMap.get('id')!);
    }

    )
  }
  getCustomerById(customerId?:string){
    this.customerService.getById(customerId!).subscribe(res=>{
      this.customer=res;
    })
  }
  updateCustomer(){
   console.log(this.customer);
   this.customerService.updateCustomer(this.customer).subscribe(res=>{
    console.log(res);
    
   })
  }
}
