import { Component, OnInit } from '@angular/core';
import { Customer } from '../../_Models/customer.model';
import { CustomerServiceService } from '../../_services/customer-service.service';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent implements OnInit {

  customer:Customer={};

  constructor(private customerService:CustomerServiceService) { 

  }

  ngOnInit(): void {
  }
  addCustomer(){
    this.customerService.createNewCustomer(this.customer).subscribe(res=>{
      console.log(res);
      
    })
  }

}
