﻿using CustomerClientAPI.EntityModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CustomerClientAPI.Controllers
{
    [Route("api")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly HttpClient _httpClient;
      
        public CustomerController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        [HttpGet]
        [Route("Customers")]
        public  async Task<IActionResult> Customers()
        {
            HttpResponseMessage response = await _httpClient.GetAsync ("https://getinvoices.azurewebsites.net/api/Customers");
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true // If you want case-insensitive property matching
            };
            if (response.IsSuccessStatusCode)
            {
                var responseA = await response.Content.ReadAsStringAsync();
                List<Customer> responseData =  JsonSerializer.Deserialize<List<Customer>>(responseA);

                return Ok(responseData);
            }
            else
            {
                return StatusCode((int)response.StatusCode, "API request failed");
            }
            
        }
        [HttpPost]
        [Route("Customer")]
        public async Task<IActionResult> CreateCustomer(Customer customer)
        {

            var custData = JsonSerializer.Serialize(customer);
            var content = new StringContent(custData, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _httpClient.PostAsync("https://getinvoices.azurewebsites.net/api/Customer", content);

            if (response.IsSuccessStatusCode)
            {
              

                return StatusCode((int)response.StatusCode, "API request succeeded");
            }
            else
            {
                return StatusCode((int)response.StatusCode, "API request failed");
            }

        }
        [HttpPost]
        [Route("Customer/{id}")]
        public async Task<IActionResult> UpdateCustomer(int id,[FromBody] Customer customer)
        {

            var custData = JsonSerializer.Serialize(customer);
            var content = new StringContent(custData, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _httpClient.PostAsync("https://getinvoices.azurewebsites.net/api/Customer/"+id, content);

            if (response.IsSuccessStatusCode)
            {


                return StatusCode((int)response.StatusCode, "API request succeeded");
            }
            else
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                int statusCode = (int)response.StatusCode;

                // Log or print the response details for debugging
                Console.WriteLine($"Status Code: {statusCode}");
                Console.WriteLine($"Response Content: {responseContent}");
                return StatusCode((int)response.StatusCode, "API request failed");
            }

        }
        [HttpGet]
        [Route("Customer/{id}")]
        public async Task<IActionResult> GetCustomerById(int id)
        {

            HttpResponseMessage response = await _httpClient.GetAsync("https://getinvoices.azurewebsites.net/api/Customer/" + id);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var customer = JsonSerializer.Deserialize<Customer>(content);
                return Ok(customer);
            }
            else
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                int statusCode = (int)response.StatusCode;
                // Log or print the response details for debugging
                Console.WriteLine($"Status Code: {statusCode}");
                Console.WriteLine($"Response Content: {responseContent}");
                return StatusCode((int)response.StatusCode, "API request failed");
            }

        }
        [HttpDelete]
        [Route("Customer/{id}")]
        public async Task<IActionResult> DeleteCustomer(int id)
        {

            HttpResponseMessage response = await _httpClient.DeleteAsync("https://getinvoices.azurewebsites.net/api/Customer/" + id);

            if (response.IsSuccessStatusCode)
            {
              
                return Ok();
            }
            else
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                int statusCode = (int)response.StatusCode;
                // Log or print the response details for debugging
                Console.WriteLine($"Status Code: {statusCode}");
                Console.WriteLine($"Response Content: {responseContent}");
                return StatusCode((int)response.StatusCode, "API request failed");
            }

        }

    }
}
